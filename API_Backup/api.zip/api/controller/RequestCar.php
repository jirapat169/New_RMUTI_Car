<?php
namespace Controller;

use \Psr\Http\Message\ResponseInterface as Response;
use \Psr\Http\Message\ServerRequestInterface as Request;

class RequestCar
{
    public function insert_update_Request(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"), true);
        $db = new \Tools\Database();
        $dataOut = null;
        if (@$rawdata["insertStatus"] == true) {
            $query = $db->query("INSERT INTO `request_car` (`reason`,
              `affiliation`,
              `location`,
              `in_korat`,
              `list_teacher`,
              `list_student`,
              `date_start`,
              `date_end`,
              `car_start`,
              `car_end`,
              `mystep`,
              `username`,
              `doc1`,
              `doc2`,
              `count_people`,
              `mapdata`
              ) VALUES ('" . @$rawdata["reason"] . "' ,
              '" . @$rawdata["affiliation"] . "' ,
              '" . @$rawdata["location"] . "' ,
              '" . @$rawdata["in_korat"] . "' ,
              '" . @$rawdata["list_teacher"] . "' ,
              '" . @$rawdata["list_student"] . "' ,
              '" . @$rawdata["date_start"] . "' ,
              '" . @$rawdata["date_end"] . "' ,
              '" . @$rawdata["car_start"] . "' ,
              '" . @$rawdata["car_end"] . "',
              '0',
              '" . @$rawdata["username"] . "',
              '" . @$rawdata["doc1"] . "',
              '" . @$rawdata["doc2"] . "',
              '" . @$rawdata["count_people"] . "',
              '" . @$rawdata["mapdata"] . "'
            )");
        } else {
            $query = $db->query("UPDATE `request_car`
              SET `reason` = '" . $rawdata["reason"] . "',
              `affiliation` = '" . $rawdata["affiliation"] . "',
              `location` = '" . $rawdata["location"] . "',
              `in_korat` = '" . $rawdata["in_korat"] . "',
              `list_teacher` = '" . $rawdata["list_teacher"] . "',
              `list_student` = '" . $rawdata["list_student"] . "',
              `date_start` = '" . $rawdata["date_start"] . "',
              `date_end` = '" . $rawdata["date_end"] . "',
              `car_start` = '" . $rawdata["car_start"] . "',
              `car_end` = '" . $rawdata["car_end"] . "',
              `username` = '" . $rawdata["username"] . "',
              `doc1` = '" . $rawdata["doc1"] . "',
              `doc2` = '" . $rawdata["doc2"] . "',
              `count_people` = '" . $rawdata["count_people"] . "',
              `mapdata` = '" . $rawdata["mapdata"] . "'
              WHERE `id` = '" . $rawdata["id"] . "'
              LIMIT 1
            ");
        }

        if ($query["isQuery"]) {
            $dataOut = array(
                "success" => true,
                "result" => array_merge(
                    $query
                ),
                "message" => "สำเร็จ",
            );
        } else {
            $finderror2 = "Duplicate";
            $finderror1 = "Data too long";
            if (strpos($query["result"], $finderror1) != false) {
                $dataOut = array(
                    "success" => false,
                    "result" => array_merge(
                        $query
                    ),
                    "message" => "ข้อมูลบางส่วนมีความยาวมากเกินไป",
                );
            } else if (strpos($query["result"], $finderror2) != false) {
                $dataOut = array(
                    "success" => false,
                    "result" => array_merge(
                        $query
                    ),
                    "message" => "ข้อมูลบางส่วนมีการใช้งานแล้ว",
                );
            } else {
                $dataOut = array(
                    "success" => false,
                    "result" => array_merge(
                        $query
                    ),
                    "message" => "error",
                );
            }
        }
        $response->getBody()->write(\json_encode($dataOut));
        return $response;
    }

    public function delete_Request(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"), true);
        $db = new \Tools\Database();
        $dataOut = null;
        $query = $db->query("DELETE FROM `request_car` WHERE `id` = '" . $rawdata["id"] . "' ");
        if ($query["isQuery"]) {
            $dataOut = array(
                "success" => true,
                "result" => array_merge(
                    $query
                ),
                "message" => "สำเร็จ",
            );
        } else {
            $dataOut = array(
                "success" => false,
                "result" => array_merge(
                    $query
                ),
                "message" => "error",
            );
        }
        $response->getBody()->write(\json_encode($dataOut));
        return $response;
    }

    public function getMyRequest(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"), true);
        $db = new \Tools\Database();
        $dataOut = null;
        $query = $db->query("SELECT d_request_car.*,request_car_step.id_request AS request_car_step_id_request
        ,request_car_step.step AS request_car_step_step
        ,request_car_step.username AS request_car_step_username
        ,request_car_step.status AS request_car_step_status
        ,request_car_step.reason AS request_car_step_reason
        FROM (SELECT * FROM request_car WHERE username = '" . $rawdata["username"] . "' ORDER BY timestamp DESC) AS d_request_car LEFT JOIN request_car_step ON d_request_car.id = request_car_step.id_request AND d_request_car.mystep = request_car_step.step");
        $dataOut = array(
            "success" => true,
            "result" => array_merge(
                $query
            ),
            "message" => "สำเร็จ",
        );
        $response->getBody()->write(\json_encode($dataOut));
        return $response;
    }

    public function getRequest(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"), true);
        $db = new \Tools\Database();
        $dataOut = null;

        $query = $db->query(
            "SELECT `request_car`.*, `request_car_detail`.*,
            `car_stock`.`id` as `c_id`,
            `car_stock`.`brand` as `c_brand`,
            `car_stock`.`model` as `c_model`,
            `car_stock`.`vehicle_type` as `c_vehicle_type`,
            `car_stock`.`registration_number` as `c_registration_number`,
            `request_car`.`timestamp` as `timestamp`,
            CONCAT(`user_request`.`prename`,`user_request`.`firstname`, ' ', `user_request`.`lastname`) as `user_request_name`,
            CONCAT(`user_request`.`position`) as `user_request_position`,
            `user_step1`.`username` as `step1_username`,
            `user_step1`.`myrole` as `step1_role`,
            CONCAT(`user_step1`.`prename`,`user_step1`.`firstname`, ' ', `user_step1`.`lastname`) as `step1_name`,
            CONCAT(`user_step2`.`prename`,`user_step2`.`firstname`, ' ', `user_step2`.`lastname`) as `step2_name`,
            CONCAT(`user_step3`.`prename`,`user_step3`.`firstname`, ' ', `user_step3`.`lastname`) as `step3_name`,
            `user_request`.`signature` as `user_signature`,
            `user_step1`.`signature` as `step1_signature`,
            `user_step2`.`signature` as `step2_signature`,
            `user_step3`.`signature` as `step3_signature`,
            `step1_request`.`reason` as `step1_reason`,
            `step2_request`.`reason` as `step2_reason`,
            `step3_request`.`reason` as `step3_reason`,
            CONCAT(`user_driver`.`prename`,`user_driver`.`firstname`, ' ', `user_driver`.`lastname`) as `user_driver_name`
            FROM `request_car`
            LEFT JOIN `request_car_step` as `step1_request`
            ON `step1_request`.`id_request` = `request_car`.`id` AND `step1_request`.`step` = '1'
            LEFT JOIN `request_car_step` as `step2_request`
            ON `step2_request`.`id_request` = `request_car`.`id` AND `step2_request`.`step` = '2'
            LEFT JOIN `request_car_step` as `step3_request`
            ON `step3_request`.`id_request` = `request_car`.`id` AND `step3_request`.`step` = '3'
            LEFT JOIN `users` as `user_step1`
            ON `user_step1`.`username` = `step1_request`.`username`
            LEFT JOIN `users` as `user_step2`
            ON `user_step2`.`username` = `step2_request`.`username`
            LEFT JOIN `users` as `user_step3`
            ON `user_step3`.`username` = `step3_request`.`username`
            LEFT JOIN `request_car_detail`
            ON `request_car`.`id` = `request_car_detail`.`id_request`
            LEFT JOIN `users` as `user_request`
            ON `request_car`.`username` = `user_request`.`username`
            LEFT JOIN `car_stock`
            ON `car_stock`.`id` = `request_car_detail`.`id_car`
            LEFT JOIN `users` as `user_driver`
            ON `user_driver`.`username` = `request_car_detail`.`user_driver`
            ORDER BY `request_car`.`mystep` ASC, `request_car`.`timestamp` DESC"
        );
        $dataOut = array(
            "success" => true,
            "result" => array_merge(
                $query
            ),
            "message" => "สำเร็จ",
        );
        $response->getBody()->write(\json_encode($dataOut));
        return $response;
    }

    public function insert_update_Step(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"), true);
        $db = new \Tools\Database();
        $dataOut = null;

        if (@$rawdata["insertStatus"] == true) {
            if (@$rawdata["step"] == "1" && @$rawdata["car_step_status"] == "1") {
                $query1 = $db->query("INSERT INTO `request_car_detail` (`id_request`,
                    `id_car`,
                    `user_driver`
                    ) VALUES ('" . @$rawdata["id_request"] . "' ,
                    '" . @$rawdata["car_detail_id_car"] . "' ,
                    '" . @$rawdata["car_detail_user_driver"] . "'
                )");
            }

            $query2 = $db->query("INSERT INTO `request_car_step` (`id_request`,
                `step`,
                `username`,
                `status`,
                `reason`
                ) VALUES ('" . @$rawdata["id_request"] . "' ,
                '" . @$rawdata["step"] . "' ,
                '" . @$rawdata["car_step_username"] . "',
                '" . @$rawdata["car_step_status"] . "',
                '" . @$rawdata["car_step_reason"] . "'
            )");

            if ($rawdata["car_step_status"] == "0") {
                $query3 = $db->query("UPDATE `request_car`
                    SET `mystep` = '5'
                    WHERE `id` = '" . @$rawdata["id_request"] . "'
                    LIMIT 1
                ");
            } else {
                $query3 = $db->query("UPDATE `request_car`
                    SET `mystep` = '" . @$rawdata["step"] . "'
                    WHERE `id` = '" . @$rawdata["id_request"] . "'
                    LIMIT 1
                ");
            }

        } else {
            if (@$rawdata["step"] == "1" && @$rawdata["car_step_status"] == "1") {
                $query1 = $db->query("UPDATE `request_car_detail`
                    SET `id_car` = '" . @$rawdata["car_detail_id_car"] . "',
                    `user_driver` = '" . @$rawdata["car_detail_user_driver"] . "'
                    WHERE `id_request` = '" . @$rawdata["id_request"] . "'
                    LIMIT 1
                ");
            }

            $query2 = $db->query("UPDATE `request_car_step`
              SET `username` = '" . @$rawdata["car_step_username"] . "',
              `status` = '" . @$rawdata["car_step_status"] . "',
              `reason` = '" . @$rawdata["car_step_reason"] . "'
              WHERE `id_request` = '" . @$rawdata["id_request"] . "'
              AND `step` = '" . @$rawdata["step"] . "'
              LIMIT 1
            ");

            if (@$rawdata["car_step_status"] == "0") {
                $query3 = $db->query("UPDATE `request_car`
                    SET `mystep` = '5'
                    WHERE `id` = '" . @$rawdata["id_request"] . "'
                    LIMIT 1
                ");
            }
        }

        if ($query2["isQuery"]) {
            $dataOut = array(
                "success" => true,
                "result" => array_merge(
                    $query2
                ),
                "message" => "สำเร็จ",
            );
        } else {
            $dataOut = array(
                "success" => false,
                "result" => array_merge(
                    $query2
                ),
                "message" => "ไม่สำเร็จ",
            );
        }
        $response->getBody()->write(\json_encode($dataOut));
        return $response;
    }

    public function getRequestChart(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"), true);
        $db = new \Tools\Database();
        $dataOut = null;

        $query = $db->query(
            "SELECT
            `request`.`yt`,
            GROUP_CONCAT(`request`.`location`,'--',`request`.`car`) as `data`
            FROM (SELECT `request_car`.`location`,
                    CONCAT(YEAR(`request_car`.`timestamp`),'-', MONTH(`request_car`.`timestamp`)) as `yt`,
                    CONCAT(`car_stock`.`vehicle_type`, '!!', `car_stock`.`brand`, '!!', `car_stock`.`color`, '!!', `car_stock`.`registration_number`) as `car`
                    FROM `request_car`
                    INNER JOIN `request_car_detail`
                    ON `request_car_detail`.`id_request` = `request_car`.`id`
                    LEFT JOIN `car_stock`
                    ON `car_stock`.`id` = `request_car_detail`.`id_car`) as `request`
            GROUP BY `request`.`yt`");

        $dataOut = array(
            "success" => true,
            "result" => array_merge(
                $query
            ),
            "message" => "สำเร็จ",
        );
        $response->getBody()->write(\json_encode($dataOut));
        return $response;
    }
}
