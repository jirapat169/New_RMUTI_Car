<?php

$app->get('/', \Controller\Home::class . ":index")->add(new \Middleware\ExampleMiddleware());
$app->get('/getPrefixname', \Controller\Home::class . ":getPrefixname");

$app->group('/user', function () use ($app) {
    $app->post('/loginmanual', \Controller\User::class . ":loginmanual");
    $app->post('/registermanual', \Controller\User::class . ":registermanual");
    $app->post('/get', \Controller\User::class . ":getUsers");
    $app->post('/del', \Controller\User::class . ":delete_User");
    $app->post('/addRoles', \Controller\User::class . ":addRoles");
    $app->post('/getRoles', \Controller\User::class . ":getRoles");
    $app->post('/deleteRoles', \Controller\User::class . ":deleteRoles");
});
$app->group('/requestcar', function () use ($app) {
    $app->post('/request', \Controller\RequestCar::class . ":insert_update_Request");
    $app->post('/delrequest', \Controller\RequestCar::class . ":delete_Request");
    $app->post('/getmyrequest', \Controller\RequestCar::class . ":getMyRequest");
    $app->post('/getRequest', \Controller\RequestCar::class . ":getRequest");
    $app->post('/managestep', \Controller\RequestCar::class . ":insert_update_Step");
    $app->get('/getRequestChart', \Controller\RequestCar::class . ":getRequestChart");
});
$app->group('/carstock', function () use ($app) {
    $app->post('/request', \Controller\CarStock::class . ":insert_update_Request");
    $app->post('/delrequest', \Controller\CarStock::class . ":delete_Request");
    $app->post('/getCarStock', \Controller\CarStock::class . ":getCarStock");
    $app->post('/getUsableCarNDriver', \Controller\CarStock::class . ":get_Usable_Driver_Car");
});
